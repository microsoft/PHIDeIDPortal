namespace AISearch.CustomFunctions
{
    public enum DeidStatus
    {
        Uploaded=1,
        RequiresJustification=2,
        JustificationApprovalPending=3,
        Competed=4
    }
}